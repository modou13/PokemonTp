package calculatriceV1;

/**
 * @author NDIAYE MAMADOU
 */

import java.io.Serializable;

public class calculObjet implements Serializable {

    // Dans cette classe je défini mon constructeur, mes mutateurs et accesseurs pour mon objet calculObjet.

    private double nombre1;
    private double nombre2;
    private String operateur;

    public calculObjet(double nombre1, String operateur, double nombre2) {
        this.nombre1 = nombre1;
        this.operateur = operateur;
        this.nombre2 = nombre2;
    }

    public void setNombre1(double nombre1) {
        this.nombre1 = nombre1;
    }

    public void setNombre2(double nombre2) {
        this.nombre2 = nombre2;
    }

    public void setOperateur(String operateur) {
        this.operateur = operateur;
    }

    public double getNombre1() {
        return nombre1;
    }

    public double getNombre2() {
        return nombre2;
    }

    public String getOperateur() {
        return operateur;
    }

    public String toString() {
        return nombre1 + operateur + nombre2;
    }
}
