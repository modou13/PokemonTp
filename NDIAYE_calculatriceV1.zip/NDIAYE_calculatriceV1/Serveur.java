package calculatriceV1;

/**
 * SERVEUR
 * @author Mamadou Ndiaye
 */

import java.io.*;
import java.net.*;

public class Serveur {

        public static void main(String args[]) throws IOException, ClassNotFoundException {

            // Nous ouvrons une connexion serveur en précisant le port que nous avons ouvert sur le client
            ServerSocket socket = new ServerSocket(1997);

            // Ici, l'attente de connexion provenant du client se fait grâce au "accept"
            Socket s = socket.accept();

            // Comme vu sur la classe Client, nous permettons la lecture d'un input venant du client
            DataInputStream inputChoix = new DataInputStream((s.getInputStream()));

            // Nous lisons l'entrée et nous l'affectons sur la variable choix qui va me permettre
            // de choisir vers quel choix l'utilisateur s'était dirigé (objet ou data).
            int choix = inputChoix.readInt();


            switch (choix) {
                case 1:

                    // Comme la classe client, un while(true) afin que les calculs se font continuellement
                    while (true) {

                        DataInputStream inputStream = new DataInputStream(s.getInputStream());
                        DataOutputStream outputStream = new DataOutputStream(s.getOutputStream());

                        // Le flush va nous permettre de vider le buffer car nous voulons revenir ici au calcul
                        // que l'utilisateur rentrera ensuite, c'est d'ailleurs pourquoi je ne ferme pas la connexion
                        // avec un socket.close();
                        outputStream.flush();

                        // Nous récuperons les valeurs entrée par l'utilisateur via le flux envoyé par le client
                        // que nous définissons sur ces variables
                        double nombre1 = inputStream.readDouble();
                        String operateur = inputStream.readUTF();
                        double nombre2 = inputStream.readDouble();
                        double resultat;

                        // Je fais appel à ma fonction calculatrice qui s'occupe des calculs et renvoit une résultat
                        // sous forme d'un double
                        resultat = calculatrice(nombre1, operateur, nombre2);

                        System.out.println("Opération reçu et résultat envoyé : ");
                        System.out.println(nombre1 + operateur + nombre2 + "=" + resultat);

                        // Notre outpout stream que nous renvoyons au client qui se chargera de lire le double
                        outputStream.writeDouble(resultat);
                    }

                case 2:
                    while (true) {

                        // Même principe avec des objets
                        ObjectInputStream inputStreamO = new ObjectInputStream(s.getInputStream());
                        ObjectOutputStream outputStreamO = new ObjectOutputStream(s.getOutputStream());
                        outputStreamO.flush();

                        // Nous récréons l'objet afin d'effecter les valeurs et utiliser les mutateurs et
                        // accesseurs afin de récupérer les valeurs de l'objet.
                        calculObjet calcul = (calculObjet) inputStreamO.readObject();
                        double nombre1 = calcul.getNombre1();
                        String operateur = calcul.getOperateur();
                        double nombre2 = calcul.getNombre2();
                        double resultat;

                        resultat = calculatrice(nombre1, operateur, nombre2);

                        System.out.println("Opération reçu et résultat envoyé : ");
                        System.out.println(nombre1 + operateur + nombre2 + "=" + resultat);

                        // Nous renvoyons le double sous forme d'un objet que nous allons caster ensuite
                        // car envoyer directement un double créer une erreur étant donné que les données envoyées
                        // sont des objets.
                        outputStreamO.writeObject(resultat);
                    }
            }
        }

        public static double calculatrice(double nombre1, String operateur, double nombre2) {

            // Switch qui lit l'opérateur et renvoie l'opération et le résultat
            double resultat = 0;
            switch(operateur) {
                case "+":
                    return resultat = nombre1 + nombre2;

                case "-":
                    return resultat = nombre1 - nombre2;

                case "*":
                    return resultat = nombre1 * nombre2;

                case "/":
                    return resultat = nombre1 / nombre2;

                default:
                    return 0;
            }
        }
    }

