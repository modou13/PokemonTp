package calculatriceV1;

/**
 * CLIENT
 * @author NDIAYE MAMADOU
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

    public class Client {

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        // Retourne l'adresse de l'host local (ma machine) afin de préparer la liaison entre
        // ma classe client et serveur. De plus je définis un nom de port que je vais utiliser
        // comme pont de connexion entre mes deux classes
        InetAddress ip = InetAddress.getLocalHost();
        int port = 1997;

        // Initialisation de mon compteur d'opération
        int compteurOperation = 0;

        // Nous ouvrons une connexion dites bidirectionnelle entre cette classe et mon autre classe
        // situé sur le même réseau (local).
        Socket socket = new Socket(ip, port);

        // Simple menu d'acceuil
        System.out.println("_________________________________________________________________");
        System.out.println("|                                                               |");
        System.out.println("|                   CALCULATRICE - Ndiaye Mamadou               |");
        System.out.println("|_______________________________________________________________|");
        System.out.println("|                                                               |");
        System.out.println("|      Opération à taper de cette manière sur la console :      |");
        System.out.println("|                     Nombre 1      [entrée]                    |");
        System.out.println("|                     Opérateur     [entrée]                    |");
        System.out.println("|                     Nombre 2      [entrée]                    |");
        System.out.println("|_______________________________________________________________|");
        System.out.println("|                                                               |");
        System.out.println("|               [1] Envoie de valeur une par une                |");
        System.out.println("|               [2] Envoie de valeur par un objet               |");
        System.out.println("|_______________________________________________________________|\n");

        // J'ai organisé mon code afin que l'utilisateur choisi de quelle manière il envoit son
        // calcul et une explication de la manière à entrer ses calculs.
        Scanner sc = new Scanner(System.in);
        System.out.print("Que voulez-vous faire (1 ou 2) : ");
        int choix = sc.nextInt();


        // Cela permet d'autoriser le programme a écrire de la data vers une sortie. Pour lire les données
        // envoyées, on utilise le inputStream pour récuperer ces mêmes données.
        // Ici j'envoie au serveur le choix que l'utilisateur a fait entre envoyer des datas ou des objets.
        DataOutputStream outputChoix = new DataOutputStream(socket.getOutputStream());
        outputChoix.writeInt(choix);

        //Mon switch où je dirige l'utilisateur vers le choix auquel il a opté
        switch (choix) {
            case 1:
                // Ce while va permettre à l'utilisateur de continuer à entrer autant d'opération possible
                // jusqu'à l'arrêt
                while (true) {

                    // Comme expliquer au dessus avec les datas mais ici nous ajouter un input.
                    // Ici nous envoyons les calculs grâce à la fonction sendData et récupérons le résultat du
                    // serveur avec cette même fonction
                    DataInputStream inputStream = new DataInputStream(socket.getInputStream());
                    DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

                    // Le compteur est incrémenté à chaque fois qu'on revient sur cette boucle
                    compteurOperation += 1;
                    System.out.println("Opération via Data N°" + compteurOperation);

                    // La fonction ci-dessous me permet de récupérer les valeurs entrées par l'utilisateur
                    // et retourne l'affichage du résultat renvoyé par le serveur (plus d'explication dans la fonction)
                    sendData(socket, inputStream, outputStream, sc);
                }

            case 2:
                while (true) {

                    // Fonctionne comme les datas mais avec des objets. On envoit des objets et on en recoit.
                    ObjectOutputStream outputObject = new ObjectOutputStream(socket.getOutputStream());
                    ObjectInputStream inputObject = new ObjectInputStream(socket.getInputStream());

                    compteurOperation += 1;
                    System.out.println("Opération via Object N°" + compteurOperation);

                    // Même rôle que la fonction sendData mais avec des objets (plus d'explication dans la fonction)
                    sendObject(socket, inputObject, outputObject, sc);
                }

            default:
                break;
        }
    }

    public static void sendData (Socket socket, DataInputStream inputStream, DataOutputStream outputStream, Scanner sc) throws IOException {

        // Ici nous récuperons les valeurs de l'utilisateur sous la forme d'un double
        System.out.println("Nombre 1 = ");
        double nombre1 = sc.nextDouble();

        // Idem, mais nous récuperons l'opérateur sur un String
        System.out.println("Opérateur : ");
        String operateur = sc.next();

        System.out.println("Nombre 2 = ");
        double nombre2 = sc.nextDouble();

        // Ici nous utilisons ce que nous avons expliquer précedemment avec le DataOutputStream où nous envoyer sur le
        // flux de données les valeurs entrées par l'utilisateur
        outputStream.writeDouble(nombre1);
        outputStream.writeUTF(operateur);
        outputStream.writeDouble(nombre2);

        // Ici nous récuperons ce que le serveur nous renvoit sous la forme d'un double puis affichons le résultat
        double resultat = inputStream.readDouble();
        System.out.println("Résultat de votre calcul  = " + resultat + "\n");
        // A partir d'ici la fonction est relancé dans le while contenu dans le main.
    }

    public static void sendObject (Socket socket, ObjectInputStream inputObject, ObjectOutputStream outputObject, Scanner sc) throws IOException, ClassNotFoundException {

        // Comme pour les datas, nous récuperons les valeurs de l'utilisateur
        System.out.println("Nombre 1 = ");
        double nombre1 = sc.nextDouble();

        System.out.println("Opérateur : ");
        String operateur = sc.next();

        System.out.println("Nombre 2 = ");
        double nombre2 = sc.nextDouble();

        // A l'instar des datas, nous entreposons les données dans un objet (voir la classe "calculObjet")
        calculObjet calcul = new calculObjet(nombre1, operateur, nombre2);

        // Avec le writeObject nous envoyons sur le flux l'objet calcul.
        outputObject.writeObject(calcul);

        // Nous récuperons ainsi le résultat en double par le serveur
        // J'ai été confronté à un problème car en effet, je voulais que le serveur renvoit le résultat sous forme
        // d'un double mais étant donné que nous utilisons des objets, j'ai casté l'objet pour permettre de récupérer
        // ce fameux résultat en double.
        double resultat = (double)inputObject.readObject();
        System.out.println("Résultat de votre calcul  = " + resultat + "\n");
    }
}
